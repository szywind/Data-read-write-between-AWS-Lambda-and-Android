/*
exports.handler = function(event, context) {
    console.log("Received event: ", event);
    console.log(event.firstName);
    console.log(event.lastname);
    
    // var params = {
    //     greetings: "Hello "+ event.firstName + " " + event.lastName + " using " + context.clientContext.deviceManufacturer
    // };
    
    
    var params = {
        firstName: event.data.firstName,
        lastName: event.data.lastName
    };
    
    context.succeed(params)
    //context.succeed("Hello "+ event.firstName + "using " + context.clientContext.deviceManufacturer);
    //context.succeed(event);
}
*/


console.log('Loading function');

var doc = require('dynamodb-doc');

var AWS = require('aws-sdk');




exports.handler = function(event, context) {
    
    
    
    
    console.log('Received event:', JSON.stringify(event, null, 2));
    console.log(event.firstName)
    console.log("bbbbbbb:", event.bbb)

    
    var params = {
        TableName: "szy-abc",
        Item:{
            'firstName':{S:event.firstName},
            'lastName':{S:event.lastName},
            'bbb':{L:JSON.parse(event.bbb)}

        },
        ConditionExpression:"attribute_not_exists(firstName)",
        ReturnValues:"ALL_OLD"
    }

/*
    var params = {
        TableName: "events",
        Item:{
            'eventName':{S: "Dinner"},
            'startDate':{S: "2012/12/12"},
            'startTime':{S: "01:10"},
            'endDate':{S: "2016/01/01"},
            'endTime':{S: "23:59"},
            'location':{S: "None"},
            'food':{L: [{S:"apple"},{S:"peach"}]},
            'friend':{L: [{S:"Gu"},{S:"Liu"}]},
            'details':{S: "None"}
        },
        ConditionExpression:"attribute_not_exists(eventName)",
        ReturnValues:"ALL_OLD"
    }
*/    
    
    var dynamodb = new AWS.DynamoDB();
    
    dynamodb.putItem(params, function(err, data) {
        if (err) {
            console.log(err);
            context.done("error");
        } // an error occurred
        else{
            console.log(data);           // successful response
            console.log(data.Responses)
            // context.succeed("done");
            context.succeed(params);
        }
    });
};